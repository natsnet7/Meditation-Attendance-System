package edu.mum.TMAttendanceReport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TmAttendanceReportApplication {

	public static void main(String[] args) {
		SpringApplication.run(TmAttendanceReportApplication.class, args);
	}

}
