-- Date info (everydays date info)
-- Date info (everydays date info)
--  Date info 2016/11
INSERT INTO `date_info`(id, date_record) VALUES(1, '2016-11-17');
INSERT INTO `date_info`(id, date_record) VALUES(2, '2016-11-19');
INSERT INTO `date_info`(id, date_record) VALUES(3, '2016-11-21');
INSERT INTO `date_info`(id, date_record) VALUES(4, '2016-11-22');
INSERT INTO `date_info`(id, date_record) VALUES(5, '2016-11-23');
INSERT INTO `date_info`(id, date_record) VALUES(6, '2016-11-25');
INSERT INTO `date_info`(id, date_record) VALUES(7, '2016-11-26');
INSERT INTO `date_info`(id, date_record) VALUES(8, '2016-11-28');
INSERT INTO `date_info`(id, date_record) VALUES(9, '2016-11-29');
INSERT INTO `date_info`(id, date_record) VALUES(10, '2016-11-30');

--  Date info 2016/12
INSERT INTO `date_info`(id, date_record) VALUES(11, '2016-12-01');
INSERT INTO `date_info`(id, date_record) VALUES(12, '2016-12-02');
INSERT INTO `date_info`(id, date_record) VALUES(13, '2016-12-03');
INSERT INTO `date_info`(id, date_record) VALUES(14, '2016-12-05');
INSERT INTO `date_info`(id, date_record) VALUES(15, '2016-12-06');
INSERT INTO `date_info`(id, date_record) VALUES(16, '2016-12-07');
INSERT INTO `date_info`(id, date_record) VALUES(17, '2016-12-08');
INSERT INTO `date_info`(id, date_record) VALUES(18, '2016-12-09');
INSERT INTO `date_info`(id, date_record) VALUES(19, '2016-12-10');
INSERT INTO `date_info`(id, date_record) VALUES(20, '2016-12-12');
INSERT INTO `date_info`(id, date_record) VALUES(21, '2016-12-13');
INSERT INTO `date_info`(id, date_record) VALUES(22, '2016-12-14');
INSERT INTO `date_info`(id, date_record) VALUES(23, '2016-12-15');
INSERT INTO `date_info`(id, date_record) VALUES(24, '2016-12-16');
INSERT INTO `date_info`(id, date_record) VALUES(25, '2016-12-17');
INSERT INTO `date_info`(id, date_record) VALUES(26, '2016-12-19');
INSERT INTO `date_info`(id, date_record) VALUES(27, '2016-12-20');
INSERT INTO `date_info`(id, date_record) VALUES(28, '2016-12-21');
INSERT INTO `date_info`(id, date_record) VALUES(29, '2016-12-22');
INSERT INTO `date_info`(id, date_record) VALUES(30, '2016-12-23');
INSERT INTO `date_info`(id, date_record) VALUES(31, '2016-12-24');
INSERT INTO `date_info`(id, date_record) VALUES(32, '2016-12-27');


--  Date info 2017/01
INSERT INTO `date_info`(id, date_record) VALUES(33, '2017-01-03');
INSERT INTO `date_info`(id, date_record) VALUES(34, '2017-01-04');
INSERT INTO `date_info`(id, date_record) VALUES(35, '2017-01-05');
INSERT INTO `date_info`(id, date_record) VALUES(36, '2017-01-06');
INSERT INTO `date_info`(id, date_record) VALUES(37, '2017-01-07');
INSERT INTO `date_info`(id, date_record) VALUES(38, '2017-01-09');
INSERT INTO `date_info`(id, date_record) VALUES(39, '2017-01-10');
INSERT INTO `date_info`(id, date_record) VALUES(40, '2017-01-11');
INSERT INTO `date_info`(id, date_record) VALUES(41, '2017-01-12');
INSERT INTO `date_info`(id, date_record) VALUES(42, '2017-01-13');
INSERT INTO `date_info`(id, date_record) VALUES(43, '2017-01-16');
INSERT INTO `date_info`(id, date_record) VALUES(44, '2017-01-17');
INSERT INTO `date_info`(id, date_record) VALUES(45, '2017-01-18');
INSERT INTO `date_info`(id, date_record) VALUES(46, '2017-01-19');
INSERT INTO `date_info`(id, date_record) VALUES(47, '2017-01-20');
INSERT INTO `date_info`(id, date_record) VALUES(48, '2017-01-21');
INSERT INTO `date_info`(id, date_record) VALUES(49, '2017-01-23');
INSERT INTO `date_info`(id, date_record) VALUES(50, '2017-01-24');
INSERT INTO `date_info`(id, date_record) VALUES(51, '2017-01-25');
INSERT INTO `date_info`(id, date_record) VALUES(52, '2017-01-26');
INSERT INTO `date_info`(id, date_record) VALUES(53, '2017-01-27');
INSERT INTO `date_info`(id, date_record) VALUES(54, '2017-01-28');
INSERT INTO `date_info`(id, date_record) VALUES(55, '2017-01-30');
INSERT INTO `date_info`(id, date_record) VALUES(56, '2017-01-31');

--  Date info 2017/02
INSERT INTO `date_info`(id, date_record) VALUES(57, '2017-02-01');
INSERT INTO `date_info`(id, date_record) VALUES(58, '2017-02-02');
INSERT INTO `date_info`(id, date_record) VALUES(59, '2017-02-03');
INSERT INTO `date_info`(id, date_record) VALUES(60, '2017-02-04');
INSERT INTO `date_info`(id, date_record) VALUES(61, '2017-02-06');
INSERT INTO `date_info`(id, date_record) VALUES(62, '2017-02-07');
INSERT INTO `date_info`(id, date_record) VALUES(63, '2017-02-08');
INSERT INTO `date_info`(id, date_record) VALUES(64, '2017-02-09');
INSERT INTO `date_info`(id, date_record) VALUES(65, '2017-02-10');
INSERT INTO `date_info`(id, date_record) VALUES(66, '2017-02-13');
INSERT INTO `date_info`(id, date_record) VALUES(67, '2017-02-14');
INSERT INTO `date_info`(id, date_record) VALUES(68, '2017-02-15');
INSERT INTO `date_info`(id, date_record) VALUES(69, '2017-02-16');

-- University addmission dates info
INSERT INTO entry(id, start_Period, date_info_id) VALUES(1, 'Nov 2016', 1);
INSERT INTO entry(id, start_Period, date_info_id) VALUES(2, 'Jan 2017', 33);
INSERT INTO entry(id, start_Period, date_info_id) VALUES(3, 'Feb 2017', 57);


-- Authentication role types
INSERT INTO `role` VALUES (1,'ROLE_ADMIN');
INSERT INTO `role` VALUES (2,'ROLE_FACULTY');
INSERT INTO `role` VALUES (3,'ROLE_STUDENT');


-- Authentication credentials
INSERT INTO `users`(user_id, active, email, password) VALUES (1, 1, 'dmebrahtu@mum.edu', '$2a$10$S/wlXEo/APzf.Sn1cO2p4.V12EJmaw.uzrHelMvkpuahjmHWnSafe');
INSERT INTO `users`(user_id, active, email, password) VALUES (2, 1, 'jndamutsa@mum.edu', '$2a$10$S/wlXEo/APzf.Sn1cO2p4.V12EJmaw.uzrHelMvkpuahjmHWnSafe');
INSERT INTO `users`(user_id, active, email, password) VALUES (3, 1, 'ngoitom@mum.edu', '$2a$10$S/wlXEo/APzf.Sn1cO2p4.V12EJmaw.uzrHelMvkpuahjmHWnSafe');
INSERT INTO `users`(user_id, active, email, password) VALUES (4, 1, 'shaileslassie@mum.edu', '$2a$10$S/wlXEo/APzf.Sn1cO2p4.V12EJmaw.uzrHelMvkpuahjmHWnSafe');
INSERT INTO `users`(user_id, active, email, password) VALUES (5, 1, 'rxing@mum.edu', '$2a$10$S/wlXEo/APzf.Sn1cO2p4.V12EJmaw.uzrHelMvkpuahjmHWnSafe');


-- User and Role join table
INSERT INTO `user_role`(user_id, role_id) VALUES (1, 3);
INSERT INTO `user_role`(user_id, role_id) VALUES (2, 1);
INSERT INTO `user_role`(user_id, role_id) VALUES (3, 1);
INSERT INTO `user_role`(user_id, role_id) VALUES (4, 2);

-- Students info
INSERT INTO `student`(student_id, first_name, last_name, bar_code, entry_id, user_id) VALUES (987073, 'Dawit', 'Mebrahtu', '9737', 1, 1);

INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986801, 'lekbigr', 'pjtvo', '7326', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986802, 'dpacsof', 'iofwb', '7698', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986803, 'mzqcoyw', 'ifjpe', '7417', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986804, 'sjhltvb', 'ehygm', '7839', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986805, 'wazvefk', 'zaqck', '7284', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986806, 'gbzfjie', 'omsnb', '7482', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986807, 'husvatb', 'vrnle', '7938', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986808, 'htgzenk', 'xevht', '7870', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986809, 'linbufh', 'wqvgi', '7623', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986810, 'ytzjgna', 'otsuv', '6047', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986811, 'mjxowlt', 'estna', '6724', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986812, 'cmgyljw', 'jzsud', '7649', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986813, 'xnuwgid', 'tupwr', '7664', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986814, 'kuiwfqt', 'mshoq', '7532', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986815, 'ecslahv', 'vudzb', '7763', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986816, 'yafnclh', 'ocyqa', '7409', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986817, 'xuaokfm', 'rkcxu', '7862', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986818, 'hymxgwc', 'kojts', '7946', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986819, 'nsgriwj', 'rkufb', '7433', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986820, 'bvrsneu', 'rinwf', '7722', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986821, 'qfsjwpe', 'qgsvx', '7375', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986822, 'wushyim', 'qenkm', '7359', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986823, 'dhuzlox', 'nwhur', '7441', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986824, 'rmqyubn', 'xlfhe', '7490', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986825, 'xivwsnj', 'zlxiw', '7474', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986826, 'xiscrta', 'tgmav', '7334', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986827, 'amunshe', 'lgakp', '7342', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986828, 'kislxbo', 'kxmps', '7672', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986829, 'toqfexp', 'trihy', '7383', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986830, 'auzsdkp', 'qnhme', '5981', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986831, 'acsnyme', 'xsmpb', '8001', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986832, 'wvdsbtj', 'sjkpq', '4514', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986833, 'iyxfcgr', 'uwlet', '5551', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986834, 'usyfvtp', 'slqyf', '6278', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986835, 'zkicoma', 'fjdpz', '7748', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986836, 'ljdavti', 'kcysd', '7847', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986837, 'btdumcq', 'zedom', '7565', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986838, 'dtiknxh', 'dcsfv', '7466', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986839, 'hmnfydc', 'qzfwp', '7425', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986840, 'xdaztsy', 'kjzdh', '7599', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986841, 'qlgaund', 'dpfny', '7714', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986842, 'uaoptjy', 'oxdgq', '7920', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986843, 'hfbaozt', 'hwxba', '7656', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986844, 'elpbawf', 'frsyj', '7896', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986845, 'wblfpnc', 'amyrg', '7573', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986846, 'rpylwbn', 'dfupm', '7771', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986847, 'iobdgjn', 'giqpc', '7581', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986848, 'pbasjqe', 'bsoaq', '5809', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986849, 'mbwljvx', 'rxcjn', '7631', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986850, 'lfsekaw', 'epfhg', '6740', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986851, 'ghmrczq', 'jnche', '7805', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986852, 'mkcopye', 'yiubj', '7516', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986853, 'bmzyjqw', 'wkyvt', '7540', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986854, 'sulkigq', 'klpzr', '5593', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986855, 'efmnova', 'izyav', '5783', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986856, 'tbelzur', 'nkjgh', '7391', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986857, 'yahbsdv', 'roucy', '7730', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986858, 'svjrbid', 'ilwuc', '7706', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986859, 'yhnctmk', 'vyjxm', '8076', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986860, 'hesjlqm', 'zkroi', '8092', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986861, 'agbicou', 'wekdf', '8118', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986862, 'jiektuc', 'kaqfu', '7557', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986863, 'wlicrqa', 'vbikq', '7755', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986864, 'azpbrwo', 'uaidg', '7953', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986865, 'yaiwcjn', 'dvwip', '3440', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986866, 'vkqomtj', 'pagyo', '2401', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986867, 'pewjkym', 'sghjn', '8050', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986868, 'iwczbfs', 'nifpa', '7524', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986869, 'sarimen', 'osyhe', '2780', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986870, 'valwjhb', 'jrlbm', '7615', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986871, 'fhrjswy', 'ncouv', '5817', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986872, 'nsbyfdh', 'lzbau', '7995', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986873, 'nfglxht', 'fayic', '7680', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986874, 'budfrvn', 'kcten', '7821', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986875, 'idopbry', 'akcxm', '6583', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986876, 'coyavls', 'cpkbe', '6542', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986877, 'qtwipnb', 'tnpji', '3820', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986878, 'ivbwkep', 'zyqpl', '8191', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986879, 'uzjolvr', 'eujmb', '8100', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986880, 'wpaxqem', 'hprib', '8126', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986881, 'byewvxh', 'nmgrj', '8134', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986882, 'ostuafr', 'hpoej', '1585', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986883, 'hpifvml', 'vzejp', '7367', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986884, 'wfxtkan', 'stxiv', '5908', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986885, 'hgfaesq', 'jkxge', '6187', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986886, 'asdgvwp', 'ymqld', '6195', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986887, 'rjkfoas', 'wovmt', '5924', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986888, 'vcpgfyw', 'uvlmj', '5676', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986889, 'npmiklv', 'cezin', '6070', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986890, 'bxsvpgh', 'vrftg', '6096', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986891, 'nuwctrg', 'xizmb', '5106', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986892, 'jkthmcp', 'lbevy', '4893', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986893, 'drukahp', 'zghwn', '5791', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986894, 'yxtbwum', 'uvqtc', '5361', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986895, 'ploretz', 'gzpsd', '4943', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986896, 'hunyxqc', 'mwihb', '7508', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986897, 'edwlbta', 'vaeql', '5767', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986898, 'gwkajbp', 'tprxl', '6062', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986899, 'xzpyugk', 'czkuv', '8316', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986900, 'rtzfeul', 'andth', '7458', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986901, 'itawjey', 'vracu', '8563', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986902, 'cqfhkis', 'fnjec', '8456', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986903, 'ervmhdz', 'lnfqy', '7854', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986904, 'jaseomq', 'pefic', '8670', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986905, 'jrwohlq', 'phfml', '8696', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986906, 'wpoevjh', 'ljpbi', '8647', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986907, 'tubvkfp', 'tcduf', '8746', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986908, 'gaefktm', 'zbviq', '8712', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986909, 'ursgpvi', 'nhimo', '8381', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986910, 'jgornbp', 'blmoh', '8688', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986911, 'owtesph', 'dgsap', '8464', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986912, 'dhtevps', 'uxsqy', '8480', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986913, 'fgnbsqy', 'qheji', '8498', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986914, 'odvahlr', 'mgifn', '8753', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986915, 'atgfvmn', 'buqlv', '8787', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986916, 'qvbizkg', 'ltfgv', '4828', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986917, 'evgrkoy', 'neshg', '8704', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986918, 'btodrzn', 'jeqoc', '8357', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986919, 'xvahozk', 'chsim', '8472', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986920, 'wfovszj', 'ruajo', '8506', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986921, 'oihqspu', 'amtzl', '8738', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986922, 'aulzqmg', 'lpmac', '8720', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986923, 'fozdwsn', 'lqmvo', '8373', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986924, 'tpcguwn', 'tvqon', '8555', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986925, 'tyoapzj', 'zqvwx', '8365', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986926, 'vnleymx', 'bwzvn', '8407', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986927, 'gdpnrzw', 'gpmjs', '8605', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986928, 'atldpkx', 'rpisk', '8597', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986929, 'atpxlic', 'mygrx', '8514', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986930, 'gvxawbu', 'plgrc', '8415', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986931, 'fxdbilu', 'avenh', '8621', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986932, 'coihprf', 'xsdhu', '8795', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986933, 'nkvlfpb', 'lmrep', '8589', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986934, 'efqsmru', 'neczt', '8423', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986935, 'pcxhlmz', 'gjlqm', '8639', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986936, 'rbhatdw', 'gvbwy', '8431', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986937, 'mkdjgfe', 'atbce', '8548', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986938, 'dlxgyra', 'lrvzy', '8530', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986939, 'dbcsyut', 'dmlhw', '8654', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986940, 'dsfjmbu', 'chryu', '8662', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986941, 'nlbspzd', 'ifvky', '8779', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986942, 'ljbfisp', 'jqnbs', '8761', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986943, 'phjogrz', 'inpgr', '5429', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986944, 'xeyksdu', 'rqebp', '8571', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986945, 'kwpnfox', 'dhtzk', '8522', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986946, 'hbnauox', 'rejtd', '8449', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986947, 'pdxftgk', 'pgnsv', '8399', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986948, 'sgrlbhf', 'jdczf', '8613', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986949, 'ajeclmt', 'qynap', '7619', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986950, 'uckagfl', 'smxcn', '7979', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986951, 'fpghzcw', 'qwetj', '4919', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986952, 'gvewjra', 'carho', '4844', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986953, 'soevgmw', 'reslj', '5189', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986954, 'qynzalk', 'lmyeq', '4927', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986955, 'ujxzhqm', 'leqdf', '5114', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986956, 'cijlbfk', 'bmwkd', '5346', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986957, 'mpoaflv', 'ikmgo', '5833', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986958, 'njhckul', 'denvw', '4935', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986959, 'khcdarb', 'lzkxh', '5353', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986960, 'ueslmvi', 'grbsv', '5635', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986961, 'ejspflb', 'wamlr', '5825', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986962, 'dwtgkba', 'fcbjd', '4068', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986963, 'qzduipt', 'dyklf', '5932', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986964, 'iabdkwz', 'ehcgi', '5544', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986965, 'qzmlvfc', 'xgtyn', '5650', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986966, 'laqnsdv', 'qyufw', '4869', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986967, 'dqhzojf', 'rwlvi', '5452', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986968, 'knslmir', 'knajm', '5239', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986969, 'audopwj', 'exqmi', '4851', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986970, 'hnogrdk', 'aosef', '5155', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986971, 'lhdmbej', 'yktav', '5890', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986972, 'fejbclp', 'uzfrx', '8266', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986973, 'qjdaycf', 'niokp', '5643', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986974, 'qphcora', 'zaexh', '5866', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986975, 'mnbhjwl', 'tlguy', '4950', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986976, 'bqvpirh', 'vdsox', '5205', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986977, 'wndkgzb', 'mthos', '5312', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986978, 'trcxkfd', 'yosmw', '5627', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986979, 'ndiyhae', 'wlghj', '5510', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986980, 'zdougjv', 'xfdmb', '5460', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986981, 'ivumojx', 'xvunh', '5163', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986982, 'eazypod', 'etuyc', '5098', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986983, 'mqyahpx', 'nkctl', '4877', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986984, 'vqfomdl', 'rofwd', '6088', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986985, 'pfkazxy', 'oberz', '5007', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986986, 'atvqcwi', 'htdmw', '7912', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986987, 'uqbymop', 'euzob', '6617', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986988, 'dfbceju', 'vyspu', '5130', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986989, 'jbxzatd', 'ulpcv', '5973', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986990, 'omzvapt', 'mctop', '4984', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986991, 'itsaunz', 'bdtie', '4992', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986992, 'ojpamvz', 'oiczx', '5957', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986993, 'hbncrmg', 'hspxd', '5718', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986994, 'qluotgm', 'feulj', '5486', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986995, 'pwdyxzb', 'ghzxi', '5387', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986996, 'jdokvbh', 'hwqpn', '5031', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986997, 'wdxezhl', 'mbyzn', '5684', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986998, 'ybgzcnq', 'sqybw', '6835', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (986999, 'izpnuej', 'zqord', '5320', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987000, 'yzjlpdc', 'gpkqj', '5338', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987001, 'mxujwea', 'yqrcv', '5197', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987002, 'pwxglhz', 'urmkg', '5692', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987003, 'nfzqvxa', 'fkdgv', '5379', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987004, 'hqdmjyr', 'cstmo', '5841', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987005, 'feoydsx', 'erukm', '5122', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987006, 'mtnjfzp', 'lihya', '5700', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987007, 'ulrvdcb', 'gorfb', '5296', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987008, 'isrmdpe', 'rtzmb', '5171', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987009, 'itmsjgh', 'elbmu', '5304', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987010, 'husmeyk', 'ergkc', '5254', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987011, 'pgdsknm', 'rvild', '5882', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987012, 'rzxfoyc', 'mjsit', '2848', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987013, 'jivwruf', 'tqwod', '5445', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987014, 'eoxfckg', 'wgnlu', '2921', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987015, 'mjaxfwl', 'whjiz', '5569', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987016, 'mqnvshp', 'bufnw', '5437', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987017, 'towsxau', 'edwhm', '5734', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987018, 'sgjfkui', 'rvjga', '5049', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987019, 'csxulpt', 'subov', '5916', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987020, 'oqyxztk', 'nyxfg', '9042', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987021, 'qkjblmf', 'txkiv', '5023', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987022, 'ipxczun', 'xefnr', '5395', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987023, 'ifqxbpk', 'kcwpz', '5478', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987024, 'gzihybl', 'qkopg', '5775', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987025, 'uwgkecz', 'exlbf', '5080', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987026, 'mtdsgav', 'zpqtr', '5403', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987027, 'vmwgjhd', 'chnzw', '5072', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987028, 'jqrenfz', 'ujabx', '5858', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987029, 'icwqsad', 'evjof', '5577', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987030, 'rypsonl', 'qzcjm', '6104', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987031, 'jvdxhfg', 'qvokp', '5536', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987032, 'mnqifjw', 'yrdlk', '5528', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987033, 'vdnrfua', 'gtzcy', '5585', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987034, 'edfvpbi', 'bmqns', '3317', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987035, 'vwogkal', 'geaiu', '5056', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987036, 'otbhsnl', 'wuqga', '4976', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987037, 'zyxcftp', 'gaifr', '5619', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987038, 'ylxbtvi', 'gired', '5502', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987039, 'rpasmkd', 'prkwd', '5742', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987040, 'dnihcou', 'lzayw', '5411', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987041, 'pcjzduw', 'gjzcv', '7797', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987042, 'dnzwcyi', 'qjtwx', '8167', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987043, 'okeqvub', 'jmacf', '5601', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987044, 'spxlkyg', 'tzhge', '5940', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987045, 'qkiyzag', 'czqyj', '5064', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987046, 'zakwhxt', 'dgzfl', '8217', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987047, 'yaoexis', 'jfirx', '5288', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987048, 'pjxcaio', 'ejygu', '5965', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987049, 'dabgycj', 'yeofn', '5270', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987050, 'gqbljwe', 'qjenc', '6120', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987051, 'nfytadj', 'fupke', '4968', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987052, 'ftjbznc', 'jowkz', '5015', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987053, 'iwskgmp', 'dplvg', '4885', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987054, 'pavisdt', 'ldrkz', '6054', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987055, 'ndmqhjz', 'cbpuj', '5759', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987056, 'imdorks', 'vugzw', '4901', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987057, 'biretcp', 'pfedq', '6039', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987058, 'tyjlzin', 'edafr', '5262', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987059, 'hnatgsu', 'hlbie', '5213', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987060, 'dumnvbf', 'ohjxn', '7904', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987061, 'oicbptz', 'ikjat', '6021', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987062, 'rnejagi', 'hpesc', '8525', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987063, 'kivgsqr', 'gbwcu', '6351', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987064, 'feyqgcl', 'vgqce', '7987', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987065, 'pnilghx', 'xepbo', '9919', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987066, 'mvlakiz', 'nktxa', '5726', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987067, 'sktwpza', 'drckg', '5999', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987068, 'hmintkc', 'lpyqt', '4886', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987069, 'vnysklr', 'jpnco', '6625', 2, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987070, 'reubmkf', 'hjond', '6138', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987071, 'zuxjafi', 'rtlbs', '9927', 1, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987072, 'hdplmjo', 'jbmqs', '6286', 3, );
INSERT INTO student(student_id, first_name, last_name, bar_code, entry_id) VALUES (987074, 'derfdrf', 'pjtvo', '7888', 2, );





-- Admins info
INSERT INTO `admin`(id, name, user_id) VALUES (1, 'Jesse', 2);
INSERT INTO `admin`(id, name, user_id) VALUES (2, 'Natsiner', 3);


-- Faculties info
INSERT INTO `faculty`(id, first_name, last_name, user_id) VALUES (1, 'Sofia', 'Haileslassie', 4);
INSERT INTO `faculty`(id, first_name, last_name, user_id) VALUES(2, 'Rujuan', 'Xing', 5);


-- TM Attendance slots
INSERT INTO `time_info`(id, time_of_day) VALUES(1, 'EAM');
INSERT INTO `time_info`(id, time_of_day) VALUES(2, 'AM');
INSERT INTO `time_info`(id, time_of_day) VALUES(3, 'PM');





-- University block dates info
INSERT INTO `block`(id, start_date, end_date, period, description) VALUES(1, '2016-11-17', '2016-11-30', 10, 'Nov 2016');
INSERT INTO `block`(id, start_date, end_date, period, description) VALUES(2, '2017-01-03', '2017-01-31', 22, 'Jan 2017');
INSERT INTO `block`(id, start_date, end_date, period, description) VALUES(3, '2017-02-01', '2017-02-16', 10, 'Feb 2017');


-- University course catalog 
INSERT INTO `course`(code, name) VALUES('CS545', 'Web Application Architecture');
INSERT INTO `course`(code, name) VALUES('CS572', 'Modern Web Applications');
INSERT INTO `course`(code, name) VALUES('CS425', 'Software Engineering');
INSERT INTO `course`(code, name) VALUES('CS472', 'Web Application Program');

-- Course offered in each block info
INSERT INTO `course_offered`(block_id, course_id, faculty_id) VALUES(1, 'CS545', 2);


-- Course offered in each block and students enrolled in the course info

INSERT INTO `course_offered_students`(course_offered_block_id, course_offered_course_id, students_student_id) VALUES(1, 'CS545', 987068);
INSERT INTO `course_offered_students`(course_offered_block_id, course_offered_course_id, students_student_id) VALUES(1, 'CS545', 987069);
INSERT INTO `course_offered_students`(course_offered_block_id, course_offered_course_id, students_student_id) VALUES(1, 'CS545', 987070);
INSERT INTO `course_offered_students`(course_offered_block_id, course_offered_course_id, students_student_id) VALUES(1, 'CS545', 987071);
INSERT INTO `course_offered_students`(course_offered_block_id, course_offered_course_id, students_student_id) VALUES(1, 'CS545', 987072);
INSERT INTO `course_offered_students`(course_offered_block_id, course_offered_course_id, students_student_id) VALUES(1, 'CS545', 987073);

-- TM attendance locations
INSERT INTO `place`(id, name) VALUES(1, 'DB');
INSERT INTO `place`(id, name) VALUES(2, 'Dome');
INSERT INTO `place`(id, name) VALUES(3, 'Ladies Palace');

-- TM attendance
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987068, 1, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987069, 1, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987070, 1, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987071, 1, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987072, 1, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987073, 1, 1, 2);

INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987068, 2, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987069, 2, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987070, 2, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987071, 2, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987072, 2, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987073, 2, 1, 2);

INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987068, 3, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987069, 3, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987070, 3, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987071, 3, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987072, 3, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987073, 3, 1, 2);

INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987070, 4, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987071, 4, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987072, 4, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987073, 4, 1, 2);

INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987068, 9, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987069, 9, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987070, 9, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987071, 9, 1, 2);

INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987068, 5, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987069, 5, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987072, 5, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987073, 5, 1, 2);

INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987068, 6, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987069, 6, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987070, 6, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987071, 6, 1, 2);

INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987068, 7, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987069, 7, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987070, 7, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987073, 7, 1, 2);

INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987071, 8, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987072, 8, 1, 2);
INSERT INTO `tm_attendance`(student_id, date, place_id, time_info_id) VALUES(987073, 8, 1, 2);

-- Students TM checking record
INSERT INTO `tmcheck`(id, student_id, number_of_checks) VALUES(1, 987073, 2);

-- Students Retreat record
INSERT INTO `retreat`(id, student_id, number_of_retreats) VALUES(1, 987073, 1);



