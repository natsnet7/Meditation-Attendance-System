package edu.mum.tmAttendanceReport.serviceImpl;

public class ServiceImplSample {

}
