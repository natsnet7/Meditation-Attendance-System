package edu.mum.tmAttendanceReport.repository;

public class repositorySample {

}
