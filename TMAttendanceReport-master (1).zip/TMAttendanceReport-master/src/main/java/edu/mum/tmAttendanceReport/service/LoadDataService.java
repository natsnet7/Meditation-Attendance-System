package edu.mum.tmAttendanceReport.service;

public interface LoadDataService {

	public void loadData();
}
