package edu.mum.tmAttendanceReport.service;

import edu.mum.tmAttendanceReport.entity.Place;

public interface PlaceService {
	public Place getPlaceByName(String name);
}
