/**
 * 
 */

$(document).ready(function(){
	$('.table .eBtn').on('click', function(event){
	
		$('.myForm #exampleModal').modal();
	});
});